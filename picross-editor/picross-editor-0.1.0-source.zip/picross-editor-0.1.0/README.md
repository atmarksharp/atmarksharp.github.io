# Picross Editor

**Keywords**: Nonogram, Griddlers, Illust Logic, Picture Logic, Picross

## Status

_**[ Not Complete! ]**_

## Dependencies

- Java Runtime Environment (JRE) 6 (or higher)

## Build from Source

Dependencies:

- Ant 1.9.4 (or higher)
- Ivy 2.3.0 (or higher)

```sh
git clone https://github.com/atmarksharp/picross-editor
cd picross-editor
ant jar
```

### Test

Dependencies:

- tesseract 3.02.02 (or higher) (ex: brew install tesseract)

```sh
ant test
```


